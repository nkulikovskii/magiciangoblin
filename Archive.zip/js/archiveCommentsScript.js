function showComments(file, width, height) {	//Скрипт для кнопки "Архив отзывоа"
	file=file + ".html"; 
	window.open(file, "_blank", "width="+width+",height="+height+",titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no"); 
}